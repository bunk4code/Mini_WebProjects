
var openIcon = document.querySelector('#openIcon');
var closeIcon = document.querySelector('#closeIcon');
var menu = document.querySelector('.menu');
var increaser = document.querySelector('.maxElement')
var decreaser = document.querySelector('.minElement')
var filterElement = document.querySelectorAll('.hero2 ul li ')
var filterImage = document.querySelectorAll('.filter_images img')

function openfun(){
    openIcon.style.display = 'none';
    closeIcon.style.display = 'block';
    menu.classList.add("active")
}


function closefun(){
    openIcon.style.display = 'block';
    closeIcon.style.display = 'none';
    menu.classList.remove("active")

}





increaser.addEventListener('click',countUpdate)
decreaser.addEventListener('click',countReduce)

var counter = document.querySelector('.counter')

var count = parseInt(counter.textContent)
function countUpdate(){
    count = count+1;
    counter.textContent = count
}


function countReduce(){
    count = count-1;
    counter.textContent = count
}


filterElement.forEach(element => {
    
    element.addEventListener('click',()=>{
        filterImage.forEach(image => {
            if(element.getAttribute('name') == 'all'){
                image.style.display = 'block';
            }
             else if (element.getAttribute('name') == image.name){
                image.style.display = 'inline-block'
             }else{
                image.style.display = 'none'
             }
            }
        )
        });
    });


var  popbtn = document.querySelector('.popup button')
var popbox = document.querySelector('.popupMessage')
var pop = document.querySelector('.popclose')
var popMain = document.querySelector('.popup')

popbtn.addEventListener('click',()=>{
    popbox.style.display = 'block'
    popMain.classList.add("popMain")
})


pop.addEventListener('click',()=>{
    popbox.style.display = 'none'
    popMain.classList.remove("popMain")


})



var leftIcon = document.querySelector('.leftIcon')
var rightIcon = document.querySelector('.rightIcon')
var slideInnerbox = document.querySelector('.sliderInnerbox')

var valuemove = 1;
var pos = 0



leftIcon.addEventListener("click",()=>{
    if(pos < 0){
        pos = pos + 800
       

        slideInnerbox.style.transform = `translateX(${pos}px)`
    }
   
   })


rightIcon.addEventListener("click",()=>{
    pos = pos - 800
    if(pos > -3200){

    slideInnerbox.style.transform = `translateX(${pos}px)`
    }else{
        pos = -3200
    slideInnerbox.style.transform = `translateX(${pos}px)`

    }
   
   
})




function searchEngine(){
    
    var inputsearch = document.querySelector('.searchInnerBox input').value.toUpperCase()
    var  table = document.querySelector('table')
    var tr = table.getElementsByTagName('tr')

    for(let i = 0 ; i<tr.length ; i++)
        {
            var td = tr[i].getElementsByTagName('td')[0];
            
            if(td)
                {
                    let textvalue = td.textContent || td.innerHTML

                    if(textvalue.toUpperCase().indexOf(inputsearch) > -1){
                        tr[i].style.display = "";
                    }
                    else{
                        tr[i].style.display = 'none'
                    }
                
                }
        }


    



 
   }