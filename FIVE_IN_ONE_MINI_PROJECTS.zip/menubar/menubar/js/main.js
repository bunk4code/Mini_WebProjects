
var openIcon = document.querySelector('#openIcon');
var closeIcon = document.querySelector('#closeIcon');
var menu = document.querySelector('.menu');
var counter = document.querySelector('.counter');
var increaser = document.querySelector('.maxElement')
var decreaser = document.querySelector('.minElement')
function openfun(){
    openIcon.style.display = 'none';
    closeIcon.style.display = 'block';
    menu.classList.add("active")
}


function closefun(){
    openIcon.style.display = 'block';
    closeIcon.style.display = 'none';
    menu.classList.remove("active")

}





increaser.addEventListener('click',countUpdate)
decreaser.addEventListener('click',countReduce)
var count = 0
counter.textContent = count

function countUpdate(){
    count = count + 1
    counter.textContent  = '' 
    counter.textContent = counter.textContent + count
}


function countReduce(){
counter.textContent = counter.textContent -1 
}


var filterElement = document.querySelectorAll('.hero2 ul li a')
var filterImage = document.querySelectorAll('.filter_images img')
filterElement.forEach(element => {
    element.addEventListener('click',()=>{
        filterImage.forEach(image => {
            if(element.name == 'all'){
                image.style.display = 'block';
            }
             else if (element.name == image.name){
                image.style.display = 'block'
             }else{
                image.style.display = 'none'
             }
            })
        });
    });


