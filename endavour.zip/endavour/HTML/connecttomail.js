
function emailSend(){
    var username = document.getElementById('name').value;
    var phone = document.getElementById('phone').value;
    var email = document.getElementById('email').value;

    var messageBody = "Name"+username+ "<br/> Phone "+phone+"<br/> Email"+email;
    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "info@endeavourshuntsolution.com",
        Password : "FCDEC5150992A7E5B97DEB3A05B12B596746",
        To : 'info@endeavourshuntsolution.com',
        From : "info.endeavours@gmail.com",
        Subject : "This is the subject",
        Body : messageBody
    }).then(
      message => alert(message)
    );
}
