import pygame
import random
import math
pygame.init()

value = 2
screen = pygame.display.set_mode((800, 600))
background = pygame.image.load("back.png")
pygame.display.set_caption("space_shooting_game")
playerImg = pygame.image.load("spaceship.png")
enemy = pygame.image.load("ufo.png")
bullet = pygame.image.load("bullet.png")
space_x = 300
space_y = 530
changeX = 0
enemy_x = random.randint(0,736)
enemy_y = 0
check_space = False
running = True
bullet_x = space_x
bullet_y = space_y - 64
score = 0
GameCrash = False
font = pygame.font.SysFont("Arial", 32, "bold")




def scoreCal():
    score_cal = font.render(f'SCORE : {score}', True, 'white')
    screen.blit(score_cal, (10, 10))

GameOver_font = pygame.font.SysFont("Arial", 52, "bold")
def Game_over():
    gameOver =GameOver_font.render(f'SCORE : {score}', True, 'white')
    screen.blit(gameOver, (300, 250))

def collision():
    distance = math.sqrt(math.pow((enemy_x-bullet_x),2)+math.pow((enemy_y-bullet_y), 2))
    if distance <= 50:
        return True

while running:
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                changeX = -value
                if score > 2:
                    value = 3
            if event.key == pygame.K_RIGHT:
                changeX = +value
                if score > 2:
                    value = 3
            if event.key == pygame.K_SPACE:
                if check_space is False:
                    check_space = True
                    bullet_x = space_x
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                changeX = 0
            if event.key == pygame.K_RIGHT:
                changeX = 0
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()

    space_x += changeX  # space_x =space_x + changeX

    if space_x <= 0:
        space_x = 0
    if space_x >= 736:
        space_x = 736

    crash = collision()
    if crash is True:
        bullet_y = space_y - 64
        check_space = False
        enemy_x = random.randint(0, 736)
        enemy_y = 0
        score += 1

    if enemy_y > 470:
        enemy_y = 2000
        Game_over()
        GameCrash = True

    if GameCrash is False:
        scoreCal()
        screen.blit(playerImg, (space_x, space_y))

    screen.blit(enemy, (enemy_x, enemy_y))
    enemy_y += 1

    if score > 2:
        enemy_y += 1.2


    if bullet_y <= 0:
        bullet_y = space_y - 64
        check_space = False


    if check_space == True:
        screen.blit(bullet, (bullet_x, bullet_y))
        bullet_y -= 2
    pygame.display.update()
