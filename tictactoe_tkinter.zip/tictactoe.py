from tkinter import *
from tkinter import messagebox

root = Tk()
root.geometry("400x400")

value = 1

def X_checkWinner():
    Xvalue = "X"
    if a.cget("text") == b.cget("text")==c.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")
    if d.cget("text") == e.cget("text")==f.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")
    if g.cget("text") == h.cget("text")==i.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")    
    if a.cget("text") == d.cget("text")==g.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")
    if b.cget("text") == e.cget("text")==h.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")
    if c.cget("text") == f.cget("text")==i.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ",)
    if a.cget("text") == e.cget("text")==i.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")
    if c.cget("text") == e.cget("text")==g.cget("text")==Xvalue:
        messagebox.showinfo("Alert","Player One is Winner = X ")


def O_checkWinner():
    Ovalue = "O"
    if a.cget("text") == b.cget("text")==c.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if d.cget("text") == e.cget("text")==f.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if g.cget("text") == h.cget("text")==i.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")    
    if a.cget("text") == d.cget("text")==g.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if b.cget("text") == e.cget("text")==h.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if c.cget("text") == f.cget("text")==i.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if a.cget("text") == e.cget("text")==i.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
    if c.cget("text") == e.cget("text")==g.cget("text")==Ovalue:
        messagebox.showinfo("Alert","Player Second is Winner == O ")
def clickEvent(val):
    global value
    

    if value % 2 != 0:
        val.config(bg="red")
        val.config(text="X")
        X_checkWinner()

    else:
        # font_style=("Calibri",)
        # val.config(font=font_style)
        val.config(bg="yellow")
        val.config(text="O")
        O_checkWinner()

    value += 1
    
font_style=("Calibri",40)
lamba = 2
mota = 10
a = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(a),font=font_style)
a.name="A"
a.grid(row=0, column=0)

b = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(b),font=font_style)
b.grid(row=0, column=1)

c = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(c),font=font_style)
c.grid(row=0, column=2)




d = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(d),font=font_style)
d.grid(row=1, column=0)

e = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(e),font=font_style)
e.grid(row=1, column=1)

f = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(f),font=font_style)
f.grid(row=1, column=2)



g = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(g),font=font_style)
g.grid(row=2, column=0)

h = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(h),font=font_style)
h.grid(row=2, column=1)

i = Button(root, text="", height=lamba, width=mota, command=lambda: clickEvent(i),font=font_style)
i.grid(row=2, column=2)
root.mainloop()
